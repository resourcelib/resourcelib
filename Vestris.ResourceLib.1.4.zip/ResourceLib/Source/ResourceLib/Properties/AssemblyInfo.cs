﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ResourceLib")]
[assembly: Guid("7126e1f4-8620-484c-806e-7f4e51524709")]
