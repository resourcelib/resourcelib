﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Version")]
[assembly: AssemblyDescription("")]
[assembly: Guid("0B3DECC6-2240-4e36-BDEE-C3747F835232")]
