﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ResourceLibUnitTests")]
[assembly: Guid("4d5aec06-7f80-454f-8c12-0fc2c734bfeb")]
